"""Version information for FLEXT dbt LDIF."""

from typing import Final

VERSION: Final[str] = "0.1.0"
