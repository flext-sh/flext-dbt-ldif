# FLEXT dbt LDIF

Advanced LDAP Data Analytics and Transformations using dbt within the FLEXT framework.

## Overview

`flext-dbt-ldif` is a specialized dbt project that provides programmatic model generation and sophisticated analytics for LDIF (LDAP Data Interchange Format) data. This project implements advanced SQL patterns, time series analysis, and anomaly detection for LDAP directory analytics.

## Features

- **Programmatic dbt Model Generation**: Models are generated via Python code rather than static SQL files
- **Advanced Analytics**: Time series analysis, anomaly detection, statistical methods
- **LDIF Processing**: Specialized functionality for LDAP data transformation and analysis
- **Quality Assurance**: Comprehensive data quality metrics and validation
- **Modern SQL Patterns**: Uses CTEs, window functions, pivots, and advanced aggregations

## Architecture

### Data Flow

```
Raw LDIF Data  Staging  Intermediate  Facts/Dimensions  Analytics/Marts
```

### Model Layers

1. **Staging (`stg_*`)**: Raw LDIF data with basic cleaning and validation
2. **Intermediate (`int_*`)**: Business logic and transformations
3. **Facts/Dimensions (`fact_*`, `dim_*`)**: Dimensional modeling
4. **Analytics/Marts (`analytics_*`)**: Advanced analytics and insights

## Installation

```bash
# Install dependencies
make install

# Install dbt packages
make dbt-deps

# Complete setup
make setup
```

## Development

### Quality Checks

```bash
# Run all quality checks (strict mode)
make check

# Individual checks
make lint              # Ruff linting
make type-check        # MyPy type checking
make test              # Unit and integration tests
make security          # Security scans
```

### dbt Commands

```bash
# Compile models
make dbt-compile

# Run models
make dbt-run

# Run tests
make dbt-test

# Generate documentation
make dbt-docs

# Complete dbt quality check
make dbt-check
```

### Testing

```bash
# All tests
make test

# Specific test types
make test-unit         # Unit tests only
make test-integration  # Integration tests only
make test-dbt          # dbt-specific tests
make test-ldif         # LDIF processing tests
```

## Project Structure

```
flext-dbt-ldif/
   src/flext_dbt_ldif/     # Python package for model generation
      cli.py              # Command-line interface
      core.py             # Core model generation logic
      __init__.py         # Package initialization
   tests/                  # Test suite
      unit/               # Unit tests
      integration/        # Integration tests
   target/                 # Compiled dbt artifacts
   dbt_packages/           # dbt package dependencies
   pyproject.toml          # Poetry configuration
   Makefile                # Development commands
   CLAUDE.md               # Development guidelines
```

## Analytics Capabilities

### Time Series Analysis
- Hourly and daily trend analysis
- Moving averages (24h, 7-day)
- Year-over-year comparisons
- Seasonal pattern detection

### Anomaly Detection
- Statistical anomaly detection using 3-sigma rules
- Baseline comparison analysis
- Risk level classification (HIGH_RISK, SUSPICIOUS, NORMAL)

### Data Quality Monitoring
- Completeness metrics
- Validity scoring
- Consistency analysis
- Automated quality scoring

### Business Intelligence
- Operational health scores
- Impact assessment metrics
- Change pattern analysis
- Security alert levels

## Contributing

This project follows FLEXT workspace standards:

1. **Zero tolerance for quality violations** - All checks must pass
2. **Use workspace virtual environment**: `/home/marlonsc/flext/.venv`
3. **Follow Poetry standards** for dependency management
4. **Test-driven development** with comprehensive coverage
5. **Security-first approach** with automated scanning

## Commands Reference

| Command | Description |
|---------|-------------|
| `make help` | Show all available commands |
| `make check` | Run all quality checks (strict mode) |
| `make dbt-compile` | Compile dbt models |
| `make dbt-run` | Execute dbt models |
| `make test` | Run comprehensive test suite |
| `make clean` | Remove all cache and build files |

## License

MIT License - see LICENSE file for details.

## FLEXT Integration

This project is part of the FLEXT enterprise data integration platform. It follows FLEXT standards for:

- **Python 3.13** compatibility
- **Poetry** dependency management
- **Standardized Makefiles** with quality gates
- **Comprehensive testing** with pytest
- **Security scanning** with bandit and safety
- **Type checking** with mypy in strict mode
- **Code quality** with ruff linting